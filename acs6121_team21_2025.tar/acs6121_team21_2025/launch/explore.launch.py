from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, ExecuteProcess, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import ThisLaunchFileDir
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    
    pkg_nav2_bringup = os.path.join(
        get_package_share_directory('nav2_bringup'), 'launch'
        
    )
    pkg_slam_toolbox = os.path.join(
        get_package_share_directory('slam_toolbox'),'launch'
    )

    return LaunchDescription([
        # Nav2 Navigation Launch
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(pkg_nav2_bringup, 'navigation_launch.py')),
            launch_arguments={
                'params_file': '/home/student/ros2_ws/src/acs6121_team21_2025/config/nav2_params.yaml',
                'use_sim_time': 'false'
            }.items()
        ),

        # RViz Launch
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(pkg_nav2_bringup, 'rviz_launch.py')),
        ),

        # SLAM Toolbox Launch
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(pkg_slam_toolbox, 'online_async_launch.py')),
        ),

        # Delayed start for waypoint_follower.py (5 seconds)
        TimerAction(
            period=5.0,
            actions=[
                ExecuteProcess(
                    cmd=[
                        'ros2', 'run', 'acs6121_team21_2025', 'waypoint_follower.py'
                    ],
                    output='screen'
                )
            ]
        ),

        # Start map_saver_server node
        ExecuteProcess(
            cmd=[
                'ros2', 'run', 'nav2_map_server', 'map_saver_server'
            ],
            output='screen'
        ),

        # Start Lifecycle Manager for map_saver
        ExecuteProcess(
            cmd=[
                'ros2', 'run', 'nav2_lifecycle_manager', 'lifecycle_manager',
                '--ros-args',
                '-p', 'autostart:=true',
                '-p', "node_names:=['map_saver']",
                '-p', 'bond_timeout:=-1.0'
            ],
            output='screen'
        ),

        # Repeated SaveMap service call every 20 seconds
        TimerAction(
            period=20.0,
            actions=[
                ExecuteProcess(
                    cmd=[
                        'ros2', 'service', 'call',
                        '/map_saver/save_map', 'nav2_msgs/srv/SaveMap',
                        "{map_topic: 'map', map_url: '/home/student/ros2_ws/src/acs6121_team21_2025/maps/explore_map', image_format: 'png'}"
                    ],
                    output='screen'
                )
            ],
        ),

        TimerAction(
            period=40.0,
            actions=[
                ExecuteProcess(
                    cmd=[
                        'ros2', 'service', 'call',
                        '/map_saver/save_map', 'nav2_msgs/srv/SaveMap',
                        "{map_topic: 'map', map_url: '/home/student/ros2_ws/src/acs6121_team21_2025/maps/explore_map', image_format: 'png'}"
                    ],
                    output='screen'
                )
            ],
        ),

        TimerAction(
            period=60.0,
            actions=[
                ExecuteProcess(
                    cmd=[
                        'ros2', 'service', 'call',
                        '/map_saver/save_map', 'nav2_msgs/srv/SaveMap',
                        "{map_topic: 'map', map_url: '/home/student/ros2_ws/src/acs6121_team21_2025/maps/explore_map', image_format: 'png'}"
                    ],
                    output='screen'
                )
            ],
        ),

        TimerAction(
            period=80.0,
            actions=[
                ExecuteProcess(
                    cmd=[
                        'ros2', 'service', 'call',
                        '/map_saver/save_map', 'nav2_msgs/srv/SaveMap',
                        "{map_topic: 'map', map_url: '/home/student/ros2_ws/src/acs6121_team21_2025/maps/explore_map', image_format: 'png'}"
                    ],
                    output='screen'
                )
            ],
        ),

        TimerAction(
            period=100.0,
            actions=[
                ExecuteProcess(
                    cmd=[
                        'ros2', 'service', 'call',
                        '/map_saver/save_map', 'nav2_msgs/srv/SaveMap',
                        "{map_topic: 'map', map_url: '/home/student/ros2_ws/src/acs6121_team21_2025/maps/explore_map', image_format: 'png'}"
                    ],
                    output='screen'
                )
            ],
        ),

        TimerAction(
            period=120.0,
            actions=[
                ExecuteProcess(
                    cmd=[
                        'ros2', 'service', 'call',
                        '/map_saver/save_map', 'nav2_msgs/srv/SaveMap',
                        "{map_topic: 'map', map_url: '/home/student/ros2_ws/src/acs6121_team21_2025/maps/explore_map', image_format: 'png'}"
                    ],
                    output='screen'
                )
            ],
        )
    ])

