import rclpy
from rclpy.node import Node
from nav2_msgs.srv import SaveMap
import signal
import sys

class MapSaver(Node):
    def __init__(self):
        super().__init__('map_saver_periodic')

        # Create the service client
        self.cli = self.create_client(SaveMap, '/map_saver/save_map')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for /map_saver/save_map service...')

        # Call save_map every 30 seconds
        self.timer = self.create_timer(30.0, self.save_map)

        # Catch shutdown signals
        signal.signal(signal.SIGINT, self.shutdown_handler)
        signal.signal(signal.SIGTERM, self.shutdown_handler)

        self.shutting_down = False

    def save_map(self):
        if self.shutting_down:
            return  # Skip if we’re already shutting down

        request = SaveMap.Request()
        request.map_topic = 'map'
        request.map_url = '/home/student/ros2_ws/src/acs6121_team21_2025/maps/explore_map'
        request.image_format = 'png'

        future = self.cli.call_async(request)
        future.add_done_callback(self.map_saved)

    def map_saved(self, future):
        if future.result() is not None:
            self.get_logger().info('Map saved successfully.')
        else:
            self.get_logger().error('Map save failed.')

    def shutdown_handler(self, signum, frame):
        if self.shutting_down:
            return  # Prevent double-trigger
        self.shutting_down = True

        self.get_logger().info('Shutdown signal received. Saving final map...')

        request = SaveMap.Request()
        request.map_topic = 'map'
        request.map_url = '/home/student/ros2_ws/src/acs6121_team21_2025/maps/explore_map'
        request.image_format = 'png'

        future = self.cli.call_async(request)
        rclpy.spin_until_future_complete(self, future)

        if future.result() is not None:
            self.get_logger().info('Final map saved successfully on exit.')
        else:
            self.get_logger().error('Final map save failed on exit.')

        rclpy.shutdown()
        sys.exit(0)

def main(args=None):
    rclpy.init(args=args)
    node = MapSaver()
    rclpy.spin(node)

if __name__ == '__main__':
    main()
