#!/usr/bin/env python3
from nav2_msgs.action import FollowWaypoints
from geometry_msgs.msg import PoseStamped
import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from tf2_ros import Buffer, TransformListener
from tf_transformations import quaternion_from_euler
import math

class WaypointFollower(Node):
    def __init__(self):
        super().__init__('waypoint_follower')

        self.client = ActionClient(self, FollowWaypoints, 'follow_waypoints')

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.timer = self.create_timer(1.0, self.try_get_initial_pose)

    def try_get_initial_pose(self):
        try:
            now = rclpy.time.Time()
            transform = self.tf_buffer.lookup_transform(
                'map', 'base_footprint', now, timeout=rclpy.duration.Duration(seconds=2.0)
            )
            x0 = transform.transform.translation.x
            y0 = transform.transform.translation.y
            self.get_logger().info(f"Robot start pose: x={x0:.2f}, y={y0:.2f}")
            self.timer.cancel()

            waypoints = self.create_waypoints_relative_to(x0, y0)
            self.send_goal(waypoints)

        except Exception as e:
            self.get_logger().warn(f"Waiting for transform: {e}")

    def create_waypoints_relative_to(self, x0, y0):
        poses = []
        relative_positions = [
            (-1.5, 0.5), (-1.5, 1.5), (-0.5, 1.5), (0.5, 1.5), (1.5, 1.5),
            (1.5, 0.5), (1.5, -0.5), (1.5, -1.5), (0.5, -1.5), (-0.5, -1.5),
            (-1.5, -1.5), (-1.5, -0.5), (0.0, 0.0)
        ]

        for i, (dx, dy) in enumerate(relative_positions):
            pose = PoseStamped()
            pose.header.frame_id = "map"
            pose.pose.position.x = x0 + dx
            pose.pose.position.y = y0 + dy

            # Face toward the next waypoint if possible
            if i < len(relative_positions) - 1:
                next_dx, next_dy = relative_positions[i + 1]
                yaw = math.atan2(next_dy - dy, next_dx - dx)
            else:
                yaw = 0.0  # Final pose faces forward

            q = quaternion_from_euler(0, 0, yaw)
            pose.pose.orientation.x = q[0]
            pose.pose.orientation.y = q[1]
            pose.pose.orientation.z = q[2]
            pose.pose.orientation.w = q[3]

            poses.append(pose)
        return poses

    def send_goal(self, waypoints):
        self.client.wait_for_server()
        goal_msg = FollowWaypoints.Goal()
        goal_msg.poses = waypoints

        send_goal_future = self.client.send_goal_async(goal_msg, feedback_callback=self.feedback_callback)
        send_goal_future.add_done_callback(self.goal_response_callback)

        self.get_logger().info("Sent waypoint goal to server.")

    def feedback_callback(self, feedback_msg):
        current_index = feedback_msg.feedback.current_waypoint
        self.get_logger().info(f"Reached waypoint {current_index + 1}")

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error('Goal was rejected!')
            return

        self.get_logger().info('Goal accepted!')
        result_future = goal_handle.get_result_async()
        result_future.add_done_callback(self.result_callback)

    def result_callback(self, future):
        result = future.result().result
        self.get_logger().info(f"Navigation finished. Completed {result.missed_waypoints} missed waypoints.")

def main(args=None):
    rclpy.init(args=args)
    node = WaypointFollower()
    rclpy.spin(node)

if __name__ == '__main__':
    main()
